# Fallout Zone: Wasteland Voxel Sim

A fully self-contained, single-file voxel survival/building game — an atompunk take on
the Minecraft formula, loosely inspired by Fallout's retro-futuristic wasteland. No
installation, no build step, no external assets: open the HTML file in a browser and play.

Built with [Three.js](https://threejs.org/) (loaded from a CDN inside the file itself).

---

## Getting Started

1. Open `atompunk-wasteland-voxel.html` in a desktop browser (Chrome, Firefox, Edge, or
   Safari — anything with WebGL support).
2. On the title screen, pick a world seed (or leave it blank for a random one), choose
   **Survival** or **Creative**, and pick a render distance.
3. Click **Enter the Wasteland**, then click the game window once to lock your mouse
   cursor and start playing.
4. Progress autosaves to your browser's local storage every ~25 seconds. Use
   **Continue Expedition** on the title screen to pick up where you left off.

This is designed for **desktop mouse + keyboard** — like the games it's inspired by,
it doesn't have touch controls.

---

## Controls

| Action | Key / Button |
|---|---|
| Move | `W A S D` |
| Look around | Mouse (click the game window to lock the cursor) |
| Jump / Fly up | `Space` |
| Sprint / Fly down | `Shift` |
| Break block / Attack | Left click (hold) |
| Place block / Use station / Sleep | Right click |
| Select hotbar slot | `1`–`9` or mouse scroll wheel |
| Open / close inventory | `E` |
| Toggle Survival ⇄ Creative | `G` |
| Set home waypoint | `H` |
| Pause menu | `Esc` |

---

## Game Modes

**Survival** — Manage Health, Hunger, and Radiation. Mine resources, craft tools and
gear, cook food, build shelter, and fight off what comes out at night. Death sends you
back to your spawn point (you keep your inventory, but stats reset).

**Creative** — Free flight, an unlimited item palette, and no threats or stats to
manage. Good for building without pressure. Switch between modes any time with `G`.

---

## Core Mechanics

### Mining & Building
Aim at a block and hold left click to break it — the required time depends on the
block's hardness and whether you're holding the right tool (pickaxe / axe / shovel).
Some materials (ore, hardened metal) need a minimum tool tier to actually drop
anything — bare hands or the wrong tool will just break the block with nothing to show
for it. Right click a block face to place whatever's in your selected hotbar slot.

### Crafting
Place a **Workbench** and right-click it to see every recipe you have the materials
for. Building consumes the listed materials and adds the result to your Field Pack
(inventory).

### Smelting
Place a **Scrap Smelter**, right-click it, and use **Load** on a recipe to feed it
material plus one piece of fuel (Wasteland Timber or Wood Planks). It processes
automatically over time — click the output slot to collect what's ready.

### Survival Stats
- **Health** drains from starvation or radiation overload, and regenerates when your
  hunger and radiation are both in good shape.
- **Hunger** drops steadily and faster while sprinting — eat food to restore it.
- **Radiation** rises near irradiated terrain, ore, and Rad-Sludge, and falls
  everywhere else. A Rad Suit anywhere in your inventory cuts the rate you gain it and
  speeds up how fast it drops.

### Day / Night Cycle
A full day takes 12 real-world minutes. Hostile mobs only spawn after dark. Craft a
**Scrap Cot** and right-click it at night to skip straight to dawn.

### Combat
Left click while aiming at a mob to attack with your equipped weapon (or bare fists).
Mobs drop materials when defeated.

---

## What's New in This Update

Ten additions on top of the original release:

1. **Sound effects** — fully synthesized in-browser (no audio files): breaking,
   placing, hits, taking damage, crafting, smelting, and picking up items. Toggle it
   off any time from the pause menu.
2. **Geiger counter** — an audible click rate that speeds up the higher your radiation
   climbs, so you can hear trouble before you check the HUD.
3. **Damage & heal screen flash** — a quick red or green vignette so hits and recovery
   actually register.
4. **Achievements & stats tracking** — blocks mined, mobs defeated, items crafted and
   smelted, deepest depth reached, and more, viewable from the pause menu with toast
   pop-ups when you unlock something.
5. **Home waypoint + compass** — press `H` to mark your base; a HUD compass and the
   minimap will always point back to it.
6. **Tool & weapon durability** — gear wears down with use and eventually breaks, shown
   as a small wear bar on the item's icon.
7. **The Scrap Hound** — a fast, low-health pack hunter that adds a different kind of
   threat to the night.
8. **Sleep** — a craftable Scrap Cot lets you skip a rough night if you'd rather not
   fight through it.
9. **Working Rad-Lanterns** — placed lanterns now actually cast light on the world
   around them at night instead of just looking lit.
10. **Minimap** — a live top-down terrain readout in the corner of the HUD, showing
    nearby mobs and your home waypoint.

---

## Tips

- Start by punching a tree for **Wasteland Timber**, craft **Wood Planks**, then a
  **Workbench** — that unlocks the rest of the tech tree.
- Ore veins get better with depth: Scrap Iron is common, Rad-Crystal is deeper and
  rarer, Uranium is deepest and rarest.
- A **Rad Suit** is a survival-mode priority once you're venturing into hot zones or
  mining near Rad-Crystal.
- Keep an eye on your tools' wear bars — carry spare materials to rebuild them before
  they break mid-task.
- Set your home waypoint (`H`) as soon as you've picked a base site; it makes it much
  easier to head back out and explore.

---

## Scope Notes

A few things were deliberately left out to keep this achievable as a single-file build:

- No cave systems — terrain is heightmap-based, with no underground tunnels.
- Crafting is a recipe list rather than a shaped 3×3 grid.
- Death doesn't drop your inventory — you keep everything and just respawn.
- No touch controls (desktop mouse + keyboard only).
- Vault Glass renders as an opaque block rather than true transparent glass.

## Technical Notes

- Everything — engine, world generation, UI, and audio — lives in one HTML file.
  There's nothing to install and no external assets to load beyond the Three.js
  library itself (pulled from a CDN).
- The world is infinite and procedurally generated from your seed; only your edits
  (blocks placed or broken) are saved, so save files stay small.
- Save data lives in your browser's local storage under the key
  `atompunk-voxel-save-v1`. Clearing your browser's site data will erase it.
- The core game logic (world generation, physics, crafting, mob AI, save/load) has an
  automated test suite behind it. The rendering and input layer is harder to verify
  outside a real browser, so if you run into a visual or control glitch, that's the
  most likely place — happy to dig in if you hit one.
